/* inresearch.ai design system demo. All data stays in this page. */
const $ = (q, root = document) => root.querySelector(q);
const $$ = (q, root = document) => Array.from(root.querySelectorAll(q));
const root = document.documentElement;
let toastTimer;
function toast(message) { clearTimeout(toastTimer); $('#toast').textContent = message; toastTimer = setTimeout(() => { $('#toast').textContent = ''; }, 4500); }
$('#themeToggle').addEventListener('click', () => { const dark = root.dataset.theme !== 'dark'; root.dataset.theme = dark ? 'dark' : 'light'; document.querySelectorAll('[data-light-logo][data-dark-logo]').forEach(img => img.setAttribute('src', img.getAttribute(dark ? 'data-dark-logo' : 'data-light-logo'))); $('#themeToggle').setAttribute('aria-label', dark ? '切换为浅色主题' : '切换为深色主题'); $('#themeToggle').setAttribute('aria-pressed', String(dark)); });
$('#textSize').addEventListener('change', e => { root.style.setProperty('--text-size', e.target.value + 'px'); });
$('#density').addEventListener('change', e => { root.dataset.density = e.target.value; });
const dialog = $('#createDialog');
$$('[data-open-modal]').forEach(b => b.addEventListener('click', () => { $('#newProject').value = ''; $('#newProject').removeAttribute('aria-invalid'); $('#newProjectError').hidden = true; dialog.showModal(); }));
$('#cancelCreate').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', event => { if (event.target === dialog) { const r = dialog.getBoundingClientRect(); if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) dialog.close(); } });
$('#createForm').addEventListener('submit', event => { event.preventDefault(); const name = $('#newProject').value.trim(); if (!name) { $('#newProjectError').hidden = false; $('#newProject').setAttribute('aria-invalid', 'true'); $('#newProject').focus(); return; } const row = document.createElement('tr'); row.dataset.name = name; row.dataset.status = '进行中'; const values = [name, '进行中', '2026-10-16', '00']; values.forEach((value, i) => { const cell = document.createElement('td'); if(i > 1) cell.className='num'; if(i === 1) {const status = document.createElement('span');status.className='status neutral';status.textContent=value;cell.append(status);} else cell.textContent = value; row.append(cell); }); $('#projectRows').prepend(row); $('#tableSearch').value = ''; $('#statusFilter').value = 'all'; filterProjects(); dialog.close(); toast('示例研究已创建；刷新页面将恢复初始演示。'); });
function filterProjects() { const query = $('#tableSearch').value.trim().toLocaleLowerCase(); const status = $('#statusFilter').value; const rows = $$('#projectRows tr'); let count = 0; rows.forEach(row => { const visible = row.dataset.name.toLocaleLowerCase().includes(query) && (status === 'all' || row.dataset.status === status); row.hidden = !visible; if (visible) count++; }); $('#resultCount').textContent = `显示 ${count} / ${rows.length} 个示例项目`; $('#noRows').hidden = count !== 0; }
$('#tableSearch').addEventListener('input', filterProjects); $('#statusFilter').addEventListener('change', filterProjects);
$('#sampleForm').addEventListener('submit', event => { event.preventDefault(); const field = $('#projectInput'); const valid = Boolean(field.value.trim()); $('#projectError').hidden = valid; field.setAttribute('aria-invalid', String(!valid)); $('#formFeedback').textContent = valid ? '已通过校验。本操作仅演示保存反馈。' : ''; if (!valid) field.focus(); });
$('#projectInput').addEventListener('input', () => { if ($('#projectInput').value.trim()) { $('#projectError').hidden = true; $('#projectInput').removeAttribute('aria-invalid'); } });
$('#textAction').addEventListener('click', () => $('#handoff').scrollIntoView({behavior:'smooth'}));
$('#focusExample').addEventListener('click', () => toast('焦点使用独立轮廓，配合键盘导航。'));
$('#dangerDemo').addEventListener('click', () => toast('这是危险操作样式演示，未移除任何资料。'));
function csvCell(value) {
  const safe = /^[=+\-@\t\r]/.test(value) ? "'" + value : value;
  return '"' + safe.replaceAll('"', '""') + '"';
}
$('#exportDemo').addEventListener('click', () => {
  const rows = $$('#projectRows tr').map(row => Array.from(row.cells).map(c => c.textContent.trim()));
  const csv = '\uFEFF' + [['研究项目（演示数据）', '状态', '示例更新时间', '文档数'], ...rows]
    .map(row => row.map(csvCell).join(',')).join('\r\n');
  const blob = new Blob([csv], {type:'text/csv;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'inresearch-ui-demo.csv'; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 500);
  toast('已导出示例 CSV。');
});
const tabs = $$('[role="tab"]');
function selectTab(tab) { tabs.forEach(t => { const active = t === tab; t.setAttribute('aria-selected', String(active)); t.tabIndex = active ? 0 : -1; $('#' + t.getAttribute('aria-controls')).hidden = !active; }); }
tabs.forEach((tab, index) => { tab.addEventListener('click', () => selectTab(tab)); tab.addEventListener('keydown', e => { let next; if(e.key === 'ArrowRight') next=(index+1)%tabs.length; if(e.key === 'ArrowLeft') next=(index+tabs.length-1)%tabs.length; if(e.key === 'Home') next=0; if(e.key === 'End') next=tabs.length-1; if(next !== undefined){e.preventDefault();selectTab(tabs[next]);tabs[next].focus();} }); });
function useChineseFont(name) { root.style.setProperty('--font-zh', `"${name}","FangSong","STFangsong",serif`); root.style.setProperty('--font-text', `"IR Latin","${name}","FangSong","STFangsong",serif`); }
(async function detectFangSong() { for (const family of ['FangSong','仿宋','STFangsong','华文仿宋']) { try { const face = new FontFace('IR Local FangSong', `local("${family}")`, {weight:'400',style:'normal'}); await face.load(); document.fonts.add(face); useChineseFont('IR Local FangSong'); $('#fontStatus').textContent = `已成功调用本机 ${family}。拉丁字体从交付包加载；跨平台仍需核验换行与字面。`; return; } catch(e) {} } $('#fontStatus').textContent = '当前浏览器未能调用本机仿宋，中文正在使用系统衬线回退。请安装合法仿宋字体，或使用下方入口载入本机字体进行预览。'; })();
$('#localFangSong').addEventListener('change', async event => { const file = event.target.files[0]; if (!file) return; try { const face = new FontFace('IR User FangSong', await file.arrayBuffer(), {weight:'400',style:'normal'}); await face.load(); document.fonts.add(face); useChineseFont('IR User FangSong'); $('#fontStatus').textContent = `已载入你选择的字体：${file.name}。请确认该文件确为合法可用的仿宋；仅本页临时使用。`; toast('本机字体已载入，未上传网络。'); } catch(e) { $('#fontStatus').textContent = '字体文件载入失败。请选择有效的 TTF、OTF、WOFF 或 WOFF2 仿宋字体文件。'; toast('字体载入失败，请检查字体格式。'); } });
